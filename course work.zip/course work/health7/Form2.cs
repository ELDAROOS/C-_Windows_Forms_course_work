﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace health7
{
    public partial class Form2 : Form
    {
        string connectionString = "Host=localhost;Port=5433;Username=postgres;Password=123;Database=health";
        int userId;
        public Form2(int userId)
        {
            InitializeComponent();
            LoadWorkoutData();
        }
        private void LoadWorkoutData()
        {
            listBox1.Items.Clear();
            List<string> workoutDataList = new List<string>(); 

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    using (NpgsqlCommand cmd = new NpgsqlCommand("SELECT workout_date, workout_data, calories FROM workouts", connection))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                DateTime workoutDate = reader.GetDateTime(0);
                                string workoutData = reader.GetString(1);
                                int calories = reader.GetInt32(2);

                                workoutDataList.Add($"{workoutDate.ToString("yyyy-MM-dd")}: {workoutData} (Calories: {calories})");
                            }
                        }
                    }

                    workoutDataList.Sort();

                    foreach (string workoutItem in workoutDataList)
                    {
                        listBox1.Items.Add(workoutItem);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке данных из базы данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox1.Text, out int duration) && textBox1.Text != "")
            {

            }
        }


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = dateTimePicker1.Value.Date;
            listBox1.ClearSelected();

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                string[] parts = listBox1.Items[i].ToString().Split(':');
                if (parts.Length >= 2)
                {
                    if (DateTime.TryParse(parts[0], out DateTime itemDate))
                    {
                        if (itemDate.Date == selectedDate)
                        {
                            listBox1.SetSelected(i, true);
                        }
                    }
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string workoutData = textBox1.Text;
            DateTime selectedDate = dateTimePicker1.Value.Date;
            int calories = Convert.ToInt32(textBox2.Text);

            if (!string.IsNullOrWhiteSpace(workoutData) && !string.IsNullOrWhiteSpace(textBox2.Text))
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        using (NpgsqlCommand cmd = new NpgsqlCommand())
                        {
                            cmd.Connection = connection;
                            cmd.CommandText = "INSERT INTO workouts (workout_date, workout_data, calories) VALUES (@date, @data, @calories)";

                            cmd.Parameters.AddWithValue("@date", NpgsqlTypes.NpgsqlDbType.Date, selectedDate);
                            cmd.Parameters.AddWithValue("@data", workoutData);
                            cmd.Parameters.AddWithValue("@calories", calories);

                            cmd.ExecuteNonQuery();
                        }
                        listBox1.Items.Add(selectedDate.ToString("yyyy-MM-dd") + ": " + workoutData + " (Calories: " + calories + ")");
                        textBox1.Clear();
                        textBox2.Clear();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при добавлении данных в базу данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите данные о тренировке и количество калорий.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string selectedItem = listBox1.SelectedItem.ToString();

                string[] parts = selectedItem.Split(':');
                if (parts.Length >= 2)
                {
                    string workoutDate = parts[0].Trim();
                    string workoutData = parts[1].Trim();

                    using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                    {
                        try
                        {
                            connection.Open();
                            using (NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM workouts WHERE workout_date = @date AND workout_data = @data", connection))
                            {
                                cmd.Parameters.AddWithValue("@date", NpgsqlTypes.NpgsqlDbType.Date, DateTime.Parse(workoutDate));
                                cmd.Parameters.AddWithValue("@data", workoutData);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка при удалении данных из базы данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    listBox1.Items.Remove(listBox1.SelectedItem);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите элемент для удаления.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int totalCalories = 0;

            foreach (var item in listBox1.Items)
            {
                string[] itemParts = item.ToString().Split(new string[] { ": ", " (Calories: ", ")" }, StringSplitOptions.RemoveEmptyEntries);
                if (itemParts.Length >= 3)
                {
                    string itemCalories = itemParts[2].Trim();
                    totalCalories += int.Parse(itemCalories);
                }
            }

            MessageBox.Show($"Общее количество калорий для {dateTimePicker1.Value.Date.ToString("yyyy-MM-dd")}: {totalCalories}", "Общее количество калорий", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
